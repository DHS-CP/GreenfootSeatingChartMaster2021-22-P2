/**
 * Write a description of interface CSALearnedSoFar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 * 
 * This was part of the 2019-20 version of the assignment so that students could reflect on their summer homework that was
 * more specific to Java syntax.
 */
public interface CSALearnedSoFar  
{
    // method signatures - implement the signature below in your own class. Make sure to
    //                     match the parameter list and return type
    public void LearnedSoFar();
}
